# Advanced notes

## Permanent Cloudflare Tunnel URL (recommended for real use)

Quick tunnels change URL on every restart, which means editing your TradingView
alert each time. A **named tunnel** with your own Cloudflare domain gives a
fixed URL.

1. `cloudflared login` (opens browser, pick your domain).
2. `cloudflared tunnel create drfx-godmode`
3. Route a hostname:
   `cloudflared tunnel route dns drfx-godmode godmode.yourdomain.com`
4. Create `config.yml` next to cloudflared:

   ```yaml
   tunnel: drfx-godmode
   credentials-file: C:\Users\<you>\.cloudflared\<TUNNEL-ID>.json
   ingress:
     - hostname: godmode.yourdomain.com
       service: http://localhost:8723
     - service: http_status:404
   ```

5. Run: `cloudflared tunnel run drfx-godmode`
6. Webhook URL becomes `https://godmode.yourdomain.com/webhook` — set once, forever.

## Auto-start the bridge on Windows boot

Create a shortcut to `start.bat` and drop it in the Startup folder:

1. Press `Win + R`, type `shell:startup`, Enter.
2. Right-click → New → Shortcut → browse to `start.bat`.

Do the same for a `cloudflared tunnel run ...` command (named tunnel), or wrap
both in a single `.bat`.

## Security

- The bridge only acts on requests that carry the correct `secret`. Keep it long
  and private; anyone with your webhook URL + secret can change your screen.
- The GeekMagic Ultra itself has **no authentication** and listens on plain HTTP.
  Keep it on your trusted LAN; do not port-forward the device to the internet.

## ngrok instead of Cloudflare

If you prefer ngrok: install it, then `ngrok http 8723`. Use the printed
`https://xxxx.ngrok-free.app/webhook` as your webhook URL. Same idea, the free
URL also rotates unless you reserve a domain.

## Customising the screen

`renderer.py` is self-contained. Colours are constants at the top (`PURPLE`,
`GREEN`, `RED`, …). Layout coordinates are in `render_godmode()`. Change fonts by
editing `_font()` (it tries Windows Arial, then bundled DejaVu, then a default).

## Multiple devices

Duplicate the folder with a different `port` and `ip` per device, and give each
TradingView alert its own webhook URL/tunnel. Or extend `device.py` to loop over
a list of IPs.
