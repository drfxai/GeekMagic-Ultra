"""
God Mode screen renderer for GeekMagic Ultra (240x240).

Draws the "GOD MODE" AI-score gauge with symbol, direction, take-profit
and stop-loss levels, matching the DrFX ULTRA OS mockup (design #10).

Pure Pillow, no network. render_godmode() returns a PIL.Image (RGB, 240x240).
"""

from __future__ import annotations
import os
from PIL import Image, ImageDraw, ImageFont

SIZE = 240  # GeekMagic Ultra panel is 240x240

# ---- palette -------------------------------------------------------------
BG          = (8, 8, 16)       # near-black background
RING_TRACK  = (38, 30, 58)     # unfilled gauge track
PURPLE      = (168, 92, 255)   # God Mode accent (magenta/violet)
PURPLE_DIM  = (120, 70, 190)
WHITE       = (240, 240, 245)
GREY        = (150, 150, 170)
GREEN       = (0, 220, 120)    # BUY
RED         = (255, 70, 70)    # SELL
AMBER       = (255, 180, 40)


# ---- fonts ---------------------------------------------------------------
def _font(size: int, bold: bool = True) -> ImageFont.FreeTypeFont:
    """Load a TrueType font, trying Windows -> Linux -> Pillow default."""
    if bold:
        candidates = [
            r"C:\Windows\Fonts\arialbd.ttf",
            r"C:\Windows\Fonts\seguisb.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        ]
    else:
        candidates = [
            r"C:\Windows\Fonts\arial.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except OSError:
                continue
    return ImageFont.load_default()


def _text_center(draw, cx, y, text, font, fill):
    l, t, r, b = draw.textbbox((0, 0), text, font=font)
    draw.text((cx - (r - l) / 2, y), text, font=font, fill=fill)
    return b - t


def _arc(draw, box, start, end, fill, width):
    draw.arc(box, start, end, fill=fill, width=width)


def render_godmode(
    score: int,
    symbol: str,
    direction: str,
    tp1=None,
    tp2=None,
    sl=None,
    confidence=None,
) -> Image.Image:
    """Render the God Mode screen. direction is 'BUY' or 'SELL'."""
    direction = (direction or "").upper()
    is_buy = direction == "BUY"
    dir_color = GREEN if is_buy else RED if direction == "SELL" else AMBER
    arrow = "\u2191" if is_buy else "\u2193" if direction == "SELL" else ""
    try:
        score = int(round(float(score)))
    except (TypeError, ValueError):
        score = 0
    score = max(0, min(100, score))

    img = Image.new("RGB", (SIZE, SIZE), BG)
    d = ImageDraw.Draw(img)

    # subtle rounded panel border
    d.rounded_rectangle([2, 2, SIZE - 3, SIZE - 3], radius=18,
                        outline=(40, 30, 60), width=2)

    # ---- title ----
    _text_center(d, SIZE // 2, 12, "GOD MODE", _font(22), PURPLE)

    # ---- gauge ----
    cx, cy, rad = SIZE // 2, 108, 46
    box = [cx - rad, cy - rad, cx + rad, cy + rad]
    ring_w = 12
    _arc(d, box, 0, 360, RING_TRACK, ring_w)               # full track
    sweep = 360 * (score / 100.0)                          # filled portion
    start = -90                                            # begin at top
    seg = 4
    n = max(1, int(sweep / seg))
    for i in range(n):
        a0 = start + i * seg
        a1 = start + (i + 1) * seg
        t = i / max(1, n - 1)
        col = (
            int(PURPLE_DIM[0] + (PURPLE[0] - PURPLE_DIM[0]) * t),
            int(PURPLE_DIM[1] + (PURPLE[1] - PURPLE_DIM[1]) * t),
            int(PURPLE_DIM[2] + (PURPLE[2] - PURPLE_DIM[2]) * t),
        )
        _arc(d, box, a0, a1, col, ring_w)

    # score number in center
    fscore = _font(40)
    l, t, r, b = d.textbbox((0, 0), str(score), font=fscore)
    d.text((cx - (r - l) / 2, cy - (b - t) / 2 - 12), str(score),
        font=fscore, fill=WHITE)
    _text_center(d, cx, cy + 20, "AI SCORE", _font(11, bold=False), GREY)

    # ---- symbol + direction ----
    label = f"{symbol}  {direction} {arrow}".strip()
    _text_center(d, SIZE // 2, 166, label, _font(20), dir_color)

    # ---- TP / SL rows ----
    def fmt(v):
        if v is None or v == "":
            return "--"
        try:
            return f"{float(v):g}"
        except (TypeError, ValueError):
            return str(v)

    y = 196
    _text_center(d, SIZE // 2, y, f"TP1 {fmt(tp1)}    TP2 {fmt(tp2)}",
                _font(14), GREEN)
    sl_line = f"SL {fmt(sl)}"
    if confidence not in (None, ""):
        try:
            sl_line = f"SL {fmt(sl)}     CONF {int(float(confidence))}%"
        except (TypeError, ValueError):
            pass
    _text_center(d, SIZE // 2, y + 20, sl_line,
                _font(14), RED if sl not in (None, "") else GREY)

    return img


if __name__ == "__main__":
    im = render_godmode(96, "XAUUSD", "BUY", tp1=3378, tp2=3386, sl=3362,
                        confidence=94)
    im.save("godmode_preview.png")
    print("saved godmode_preview.png", im.size)
