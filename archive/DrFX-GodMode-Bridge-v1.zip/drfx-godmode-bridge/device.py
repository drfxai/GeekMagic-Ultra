"""
GeekMagic Ultra device client.

Uploads a 240x240 JPEG to the device over its plain-HTTP LAN server and
switches it to the Photo-Album theme so the image is shown.

Stock-firmware endpoints:
    POST /doUpload?dir=/image/        (multipart file upload)
    GET  /set?img=/image/<name>       (select the uploaded image)
    GET  /set?theme=3                 (Photo Album theme)

Some newer Ultra units (SD_PRO firmware) use /photo/upload + /photo/toggle;
set FIRMWARE = "sd_pro" in config to use those instead.
"""

from __future__ import annotations
import io
import requests

REMOTE_NAME = "godmode.jpg"          # filename stored on the device
TIMEOUT = 8


def _url(ip: str, path: str) -> str:
    ip = ip.strip().rstrip("/")
    if not ip.startswith("http"):
        ip = "http://" + ip
    return ip + path


def push_image(img, ip: str, firmware: str = "stock") -> None:
    """Upload a PIL image to the device and display it. Raises on failure."""
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=90)
    data = buf.getvalue()

    if firmware == "sd_pro":
        _push_sd_pro(ip, data)
    else:
        _push_stock(ip, data)


def _push_stock(ip: str, data: bytes) -> None:
    files = {"file": (REMOTE_NAME, data, "image/jpeg")}
    r = requests.post(_url(ip, "/doUpload?dir=/image/"), files=files,
                    timeout=TIMEOUT)
    r.raise_for_status()
    # select the image, then make sure Photo-Album theme is active
    requests.get(_url(ip, f"/set?img=/image/{REMOTE_NAME}"), timeout=TIMEOUT)
    requests.get(_url(ip, "/set?theme=3"), timeout=TIMEOUT)


def _push_sd_pro(ip: str, data: bytes) -> None:
    files = {"file": (REMOTE_NAME, data, "image/jpeg")}
    r = requests.post(_url(ip, "/photo/upload"), files=files, timeout=TIMEOUT)
    r.raise_for_status()
    requests.get(_url(ip, "/photo/toggle"), timeout=TIMEOUT)


def ping(ip: str) -> bool:
    """Return True if the device answers on HTTP."""
    try:
        requests.get(_url(ip, "/"), timeout=4)
        return True
    except requests.RequestException:
        return False
