"""
DrFX God Mode Bridge
====================
Receives TradingView "God Mode" alerts on a webhook, renders the God Mode
screen (240x240) and pushes it to a GeekMagic Ultra display.

TradingView  --webhook JSON-->  this bridge  --image-->  GeekMagic Ultra

Run:      python bridge.py
Test:     python bridge.py --test        (renders + pushes a sample signal)
          python bridge.py --preview     (renders a sample PNG, no device)
"""

from __future__ import annotations
import configparser
import json
import os
import sys
import datetime

from flask import Flask, request, jsonify

import device
from renderer import render_godmode

HERE = os.path.dirname(os.path.abspath(__file__))
STATE_FILE = os.path.join(HERE, "last_signal.json")

# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------
def load_config():
    path = os.path.join(HERE, "config.ini")
    if not os.path.exists(path):
        path = os.path.join(HERE, "config.example.ini")
        print("[warn] config.ini not found - using config.example.ini")
    cfg = configparser.ConfigParser()
    cfg.read(path)
    return cfg


CFG = load_config()
DEVICE_IP = CFG.get("device", "ip", fallback="192.168.1.50")
FIRMWARE  = CFG.get("device", "firmware", fallback="stock")
PORT      = CFG.getint("server", "port", fallback=8723)
SECRET    = CFG.get("server", "secret", fallback="")
DERIVE    = CFG.getboolean("signal", "derive", fallback=True)
TP1_PCT   = CFG.getfloat("signal", "tp1_pct", fallback=0.30)
TP2_PCT   = CFG.getfloat("signal", "tp2_pct", fallback=0.60)
SL_PCT    = CFG.getfloat("signal", "sl_pct", fallback=0.25)

app = Flask(__name__)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _to_float(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def parse_signal(payload: dict) -> dict:
    """Normalise a God Mode alert payload into render fields."""
    direction = str(payload.get("direction") or payload.get("action")
                    or payload.get("side") or "").upper()
    if direction in ("LONG", "BULL", "BULLISH"):
        direction = "BUY"
    elif direction in ("SHORT", "BEAR", "BEARISH"):
        direction = "SELL"

    symbol = str(payload.get("symbol") or payload.get("ticker") or "").upper()
    score = payload.get("score", payload.get("ai_score", payload.get("confidence", 0)))
    confidence = payload.get("confidence")

    tp1 = _to_float(payload.get("tp1"))
    tp2 = _to_float(payload.get("tp2"))
    sl  = _to_float(payload.get("sl"))
    price = _to_float(payload.get("price") or payload.get("close"))

    # derive TP/SL from price if missing and enabled
    if DERIVE and price is not None:
        up = direction == "BUY"
        sign = 1 if up else -1
        if tp1 is None:
            tp1 = price * (1 + sign * TP1_PCT / 100)
        if tp2 is None:
            tp2 = price * (1 + sign * TP2_PCT / 100)
        if sl is None:
            sl = price * (1 - sign * SL_PCT / 100)

    return dict(score=score, symbol=symbol, direction=direction,
                tp1=tp1, tp2=tp2, sl=sl, confidence=confidence)


def render_and_push(fields: dict):
    img = render_godmode(**fields)
    device.push_image(img, DEVICE_IP, FIRMWARE)
    with open(STATE_FILE, "w") as f:
        json.dump(fields, f)
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] pushed  {fields['symbol']} {fields['direction']} "
        f"score={fields['score']} -> {DEVICE_IP}")


# --------------------------------------------------------------------------
# routes
# --------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def home():
    return "DrFX God Mode Bridge is running. POST alerts to /webhook", 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify(ok=True, device=DEVICE_IP, reachable=device.ping(DEVICE_IP))


@app.route("/webhook", methods=["POST"])
def webhook():
    # TradingView sends text/plain; parse leniently
    raw = request.get_data(as_text=True) or ""
    try:
        payload = json.loads(raw) if raw.strip().startswith("{") else {}
    except json.JSONDecodeError:
        return jsonify(ok=False, error="invalid JSON"), 400

    if not payload:
        return jsonify(ok=False, error="empty or non-JSON body"), 400

    if SECRET and str(payload.get("secret", "")) != SECRET:
        return jsonify(ok=False, error="bad secret"), 401

    fields = parse_signal(payload)
    if not fields["symbol"] or not fields["direction"]:
        return jsonify(ok=False, error="missing symbol/direction"), 400

    try:
        render_and_push(fields)
    except Exception as e:  # noqa: BLE001  - report device errors to caller
        print(f"[error] push failed: {e}")
        return jsonify(ok=False, error=f"device push failed: {e}"), 502

    return jsonify(ok=True, shown=fields), 200


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def _sample():
    return dict(score=96, symbol="XAUUSD", direction="BUY",
                tp1=3378, tp2=3386, sl=3362, confidence=94)


def main():
    if "--preview" in sys.argv:
        render_godmode(**_sample()).save(os.path.join(HERE, "preview.png"))
        print("wrote preview.png"); return
    if "--test" in sys.argv:
        print(f"pushing sample signal to {DEVICE_IP} ({FIRMWARE}) ...")
        render_and_push(_sample())
        print("done - check your GeekMagic Ultra"); return

    print("=" * 58)
    print(" DrFX God Mode Bridge")
    print(f"   device   : {DEVICE_IP}  ({FIRMWARE} firmware)")
    print(f"   listening: http://0.0.0.0:{PORT}/webhook")
    print(f"   secret   : {'set' if SECRET else 'NOT SET (open!)'}")
    print("=" * 58)
    app.run(host="0.0.0.0", port=PORT)


if __name__ == "__main__":
    main()
