# DrFX God Mode Bridge → GeekMagic Ultra

Shows your TradingView **God Mode** signal on a GeekMagic Ultra screen, with the
score, symbol, direction, take-profits and stop-loss updating live on every alert.

```
TradingView (God Mode alert)
        │  webhook JSON
        ▼
Cloudflare Tunnel  ──►  DrFX God Mode Bridge  (this app, on your PC)
                                │  renders a 240×240 "God Mode" image
                                ▼
                        GeekMagic Ultra (your WiFi)
```

**Why a bridge?** The Ultra can only *display an image* pushed to it over your
local network — it cannot receive a TradingView webhook or draw trading data on
its own. This bridge receives the alert, draws the God Mode screen, and pushes it
to the device. It runs on your Windows PC (must be on when alerts fire and on the
same WiFi as the Ultra).

---

## 1. Install (Windows, one click)

1. Install **Python 3.10+** from https://python.org (tick *"Add Python to PATH"*).
2. Unzip this folder anywhere, e.g. `C:\DrFX-GodMode-Bridge`.
3. Double-click **`start.bat`**. The first run creates a virtual environment,
   installs dependencies, and creates `config.ini`. Leave the window open — that
   window running *is* the bridge.

## 2. Configure

Open **`config.ini`** and set:

| Setting            | What to put                                                         |
|--------------------|---------------------------------------------------------------------|
| `[device] ip`      | Your Ultra's IP on WiFi (router client list, or `smartclock.local`) |
| `[device] firmware`| `stock` (default). If images never show, try `sd_pro`.              |
| `[server] port`    | Leave as `8723` unless it clashes with something.                   |
| `[server] secret`  | A long random string. **Use the same value in the alert JSON.**     |

Find your Ultra's IP: on the device, look under WiFi/Settings, or check your
router's connected-devices list for a host named `smartclock`.

Test the connection to your device (no TradingView needed):

```
.venv\Scripts\activate
python bridge.py --test
```

You should see the God Mode sample screen appear on your Ultra within a second.
`python bridge.py --preview` writes `preview.png` without touching the device.

## 3. Expose the bridge with Cloudflare Tunnel

TradingView can only call a public URL, but the bridge runs on your LAN. A free
Cloudflare Tunnel bridges the gap — no port forwarding, no fixed IP.

1. Download **cloudflared** for Windows:
   https://developers.cloudflare.com/cloudflare-tunnel/downloads/
   (Get `cloudflared-windows-amd64.exe`, rename it to `cloudflared.exe`.)
2. With the bridge running (`start.bat`), open a **second** terminal and run:

   ```
   cloudflared tunnel --url http://localhost:8723
   ```

3. It prints a public URL like `https://random-words.trycloudflare.com`.
   Your webhook URL is that address **+ `/webhook`**:

   ```
   https://random-words.trycloudflare.com/webhook
   ```

   > Quick tunnels get a new URL each restart. For a permanent URL, set up a
   > named tunnel with your own Cloudflare domain (see NOTES.md).

## 4. Point TradingView at it

In TradingView, open your **God Mode** alert → **Notifications** tab → tick
**Webhook URL** and paste the tunnel URL from step 3.

In the alert's **Message** box, paste this JSON. TradingView replaces the
`{{...}}` placeholders at fire time — map them to your God Mode plots/inputs:

```json
{
  "secret": "PASTE-THE-SAME-SECRET-AS-config.ini",
  "symbol": "{{ticker}}",
  "direction": "{{strategy.order.action}}",
  "score": 96,
  "price": {{close}},
  "tp1": 0,
  "tp2": 0,
  "sl": 0,
  "confidence": 94
}
```

Field reference:

| Field        | Required | Notes                                                             |
|--------------|----------|-------------------------------------------------------------------|
| `secret`     | yes      | Must equal `[server] secret` in config.ini.                       |
| `symbol`     | yes      | `{{ticker}}` or a fixed string like `"XAUUSD"`.                   |
| `direction`  | yes      | `BUY`/`SELL` (also accepts LONG/SHORT/BULLISH/BEARISH).          |
| `score`      | no       | God Mode AI score 0–100 shown in the ring. Defaults to 0.        |
| `tp1`, `tp2` | no       | Take-profit levels. If your indicator plots them, send them.     |
| `sl`         | no       | Stop-loss level.                                                 |
| `price`      | no       | If tp/sl are omitted, they're derived from price (see config).   |
| `confidence` | no       | Optional % shown next to SL.                                     |

If your God Mode script exposes TP/SL as plot values, use its serial/webhook
variables in place of the `0`s (e.g. `"tp1": {{plot_0}}`). If you can't get them
from the alert, leave them out and set `derive = true` in config to auto-calc
from `price`.

## 5. Go live

1. `start.bat` running.
2. `cloudflared` running with your webhook URL in the alert.
3. When God Mode fires, the Ultra updates to that signal.

Sanity check without TradingView (replace URL + secret):

```
curl -X POST https://your-tunnel.trycloudflare.com/webhook ^
 -H "Content-Type: application/json" ^
 -d "{\"secret\":\"YOURSECRET\",\"symbol\":\"XAUUSD\",\"direction\":\"BUY\",\"score\":96,\"tp1\":3378,\"tp2\":3386,\"sl\":3362,\"confidence\":94}"
```

---

## Troubleshooting

- **Image doesn't appear:** confirm the IP in a browser — `http://<ultra-ip>/`
  should load the device page. Try `firmware = sd_pro`. Make sure the Ultra and
  PC are on the same WiFi.
- **TradingView shows an error:** the tunnel URL must end in `/webhook` and the
  bridge + cloudflared must both be running.
- **401 bad secret:** the `secret` in the alert JSON ≠ `config.ini`.
- **Screen reverts after device reboot:** uploaded images are cleared on reboot;
  the next alert re-pushes. The bridge also caches the last signal in
  `last_signal.json`.

See **NOTES.md** for auto-start on boot and a permanent Cloudflare URL.

## Files

| File                 | Purpose                                              |
|----------------------|------------------------------------------------------|
| `start.bat`          | One-click setup + run (Windows).                     |
| `bridge.py`          | Webhook server; parses alerts, pushes to device.     |
| `renderer.py`        | Draws the 240×240 God Mode screen (Pillow).          |
| `device.py`          | Uploads/selects the image on the GeekMagic Ultra.    |
| `config.example.ini` | Template — copied to `config.ini` on first run.      |
| `requirements.txt`   | Python dependencies.                                 |
