@echo off
REM ==========================================================================
REM  DrFX God Mode Bridge - one-click launcher for Windows
REM  First run: creates a virtual env and installs dependencies.
REM  Later runs: just starts the bridge.
REM ==========================================================================
cd /d "%~dp0"

if not exist ".venv\" (
    echo [setup] Creating virtual environment...
    python -m venv .venv
    call ".venv\Scripts\activate.bat"
    echo [setup] Installing dependencies...
    python -m pip install --upgrade pip >nul
    python -m pip install -r requirements.txt
) else (
    call ".venv\Scripts\activate.bat"
)

if not exist "config.ini" (
    echo [setup] Creating config.ini from example - EDIT IT before real use.
    copy /y config.example.ini config.ini >nul
)

echo.
echo Starting DrFX God Mode Bridge...  (press Ctrl+C to stop)
echo.
python bridge.py
pause
